
    import React from 'react';
    import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
    import Layout from '@/components/Layout';
    import HomePage from '@/pages/HomePage';
    import TournamentsPage from '@/pages/TournamentsPage';
    import LeaderboardsPage from '@/pages/LeaderboardsPage';
    import TournamentDetailsPage from '@/pages/TournamentDetailsPage';
    import RegisterPage from '@/pages/RegisterPage';
    import LoginPage from '@/pages/LoginPage';
    import AdminDashboardPage from '@/pages/AdminDashboardPage';
    import OrganizerDashboardPage from '@/pages/OrganizerDashboardPage';
    import NotFoundPage from '@/pages/NotFoundPage';
    import { Toaster } from '@/components/ui/toaster';
    import { ThemeProvider } from '@/components/ThemeProvider.jsx';
    import { AuthProvider, useAuth } from '@/contexts/AuthContext';

    const ProtectedRoute = ({ children, roles }) => {
      const { user } = useAuth();
      if (!user) {
        return <Navigate to="/login" replace />;
      }
      if (roles && !roles.includes(user.role)) {
        return <Navigate to="/unauthorized" replace />; 
      }
      return children;
    };

    const AppContent = () => {
      return (
        <ThemeProvider defaultTheme="dark" storageKey="vite-ui-theme">
          <Router>
            <Layout>
              <Routes>
                <Route path="/" element={<HomePage />} />
                <Route path="/tournaments" element={<TournamentsPage />} />
                <Route path="/tournaments/:id" element={<TournamentDetailsPage />} />
                <Route path="/leaderboards" element={<LeaderboardsPage />} />
                <Route path="/register" element={<RegisterPage />} />
                <Route path="/login" element={<LoginPage />} />
                <Route 
                  path="/admin" 
                  element={
                    <ProtectedRoute roles={['admin']}>
                      <AdminDashboardPage />
                    </ProtectedRoute>
                  } 
                />
                <Route 
                  path="/organizer" 
                  element={
                    <ProtectedRoute roles={['organizer', 'admin']}>
                      <OrganizerDashboardPage />
                    </ProtectedRoute>
                  } 
                />
                <Route path="/unauthorized" element={<NotFoundPage message="You are not authorized to view this page." />} />
                <Route path="*" element={<NotFoundPage />} />
              </Routes>
            </Layout>
            <Toaster />
          </Router>
        </ThemeProvider>
      );
    };

    function App() {
      return (
        <AuthProvider>
          <AppContent />
        </AuthProvider>
      );
    }

    export default App;
  