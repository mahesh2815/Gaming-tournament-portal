
    import React, { useState, useEffect } from 'react';
    import { Link } from 'react-router-dom';
    import { Button } from '@/components/ui/button';
    import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
    import { Input } from '@/components/ui/input';
    import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
    import { motion, AnimatePresence } from 'framer-motion';
    import { CalendarDays, Trophy, Users, Search, Filter, LayoutList as ListCollapse, Grid } from 'lucide-react';
    import { useToast } from '@/components/ui/use-toast';

    const MotionCard = motion(Card);

    const initialTournaments = [
      { id: 1, name: 'Valorant Vanguard Series', game: 'Valorant', date: '2025-08-10', prize: '$15,000', participants: 128, slots: 128, status: 'Open', type: 'Online', imgKey: 'Valorant agent lineup' },
      { id: 2, name: 'League of Legends Championship', game: 'League of Legends', date: '2025-08-20', prize: '$20,000', participants: 60, slots: 64, status: 'Open', type: 'Online', imgKey: 'League of Legends champions battle' },
      { id: 3, name: 'CS:GO Masters Cup', game: 'Counter-Strike: GO', date: '2025-09-01', prize: '$12,000', participants: 32, slots: 32, status: 'Closed', type: 'LAN', imgKey: 'CSGO CT vs T confrontation' },
      { id: 4, name: 'Rocket League Rumble', game: 'Rocket League', date: '2025-09-15', prize: '$8,000', participants: 45, slots: 64, status: 'Open', type: 'Online', imgKey: 'Rocket League car aerial shot' },
      { id: 5, name: 'Dota 2 Titans Clash', game: 'Dota 2', date: '2025-10-01', prize: '$25,000', participants: 16, slots: 16, status: 'Upcoming', type: 'Online', imgKey: 'Dota 2 heroes mid-battle' },
      { id: 6, name: 'Street Fighter Showdown', game: 'Street Fighter 6', date: '2025-08-25', prize: '$3,000', participants: 50, slots: 128, status: 'Open', type: 'In-Person', imgKey: 'Street Fighter characters Ryu vs Ken' },
      { id: 7, name: 'Overwatch Champions Series', game: 'Overwatch 2', date: '2025-09-05', prize: '$10,000', participants: 28, slots: 32, status: 'Open', type: 'Online', imgKey: 'Overwatch 2 heroes posing' },
      { id: 8, name: 'PUBG Mobile Pro League', game: 'PUBG Mobile', date: '2025-08-15', prize: '$5,000', participants: 100, slots: 100, status: 'Closed', type: 'Online', imgKey: 'PUBG Mobile squad in action' },
    ];
    
    const gamesList = [...new Set(initialTournaments.map(t => t.game))];
    const statusList = [...new Set(initialTournaments.map(t => t.status))];
    const typeList = [...new Set(initialTournaments.map(t => t.type))];

    const TournamentsPage = () => {
      const [tournaments, setTournaments] = useState([]);
      const [searchTerm, setSearchTerm] = useState('');
      const [filterGame, setFilterGame] = useState('all');
      const [filterStatus, setFilterStatus] = useState('all');
      const [filterType, setFilterType] = useState('all');
      const [viewMode, setViewMode] = useState('grid'); // 'grid' or 'list'
      const { toast } = useToast();

      useEffect(() => {
        const storedTournaments = localStorage.getItem('tournaments');
        if (storedTournaments) {
          setTournaments(JSON.parse(storedTournaments));
        } else {
          setTournaments(initialTournaments);
          localStorage.setItem('tournaments', JSON.stringify(initialTournaments));
        }
      }, []);

      const filteredTournaments = tournaments.filter(tournament => {
        return (
          tournament.name.toLowerCase().includes(searchTerm.toLowerCase()) &&
          (filterGame === 'all' || tournament.game === filterGame) &&
          (filterStatus === 'all' || tournament.status === filterStatus) &&
          (filterType === 'all' || tournament.type === filterType)
        );
      });

      const handleRegister = (tournamentName) => {
        toast({
          title: "Registration Successful!",
          description: `You've registered for ${tournamentName}. Check your email for details.`,
          variant: "default",
          duration: 4000,
        });
      };

      return (
        <div className="space-y-8">
          <motion.div
            initial={{ opacity: 0, y: -30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-4xl md:text-5xl font-extrabold text-center mb-4 text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent">
              Explore Tournaments
            </h1>
            <p className="text-lg text-slate-400 text-center mb-10 max-w-2xl mx-auto">
              Find your next challenge. Browse upcoming, ongoing, and past tournaments across various games.
            </p>
          </motion.div>

          {/* Filters and Search */}
          <motion.div 
            className="p-6 glassmorphic-card space-y-4 md:space-y-0 md:flex md:items-end md:justify-between gap-4"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <div className="flex-grow relative">
              <Input
                type="text"
                placeholder="Search tournaments..."
                className="pl-10 pr-4 py-3 text-base bg-slate-700/50 border-slate-600 focus:border-primary"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-slate-400" />
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:flex gap-3">
              <Select value={filterGame} onValueChange={setFilterGame}>
                <SelectTrigger className="w-full md:w-[150px] bg-slate-700/50 border-slate-600">
                  <SelectValue placeholder="Filter by Game" />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 border-slate-700 text-slate-200">
                  <SelectItem value="all">All Games</SelectItem>
                  {gamesList.map(game => <SelectItem key={game} value={game}>{game}</SelectItem>)}
                </SelectContent>
              </Select>
              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger className="w-full md:w-[150px] bg-slate-700/50 border-slate-600">
                  <SelectValue placeholder="Filter by Status" />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 border-slate-700 text-slate-200">
                  <SelectItem value="all">All Statuses</SelectItem>
                  {statusList.map(status => <SelectItem key={status} value={status}>{status}</SelectItem>)}
                </SelectContent>
              </Select>
               <Select value={filterType} onValueChange={setFilterType}>
                <SelectTrigger className="w-full md:w-[150px] bg-slate-700/50 border-slate-600">
                  <SelectValue placeholder="Filter by Type" />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 border-slate-700 text-slate-200">
                  <SelectItem value="all">All Types</SelectItem>
                  {typeList.map(type => <SelectItem key={type} value={type}>{type}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
             <div className="flex items-center justify-end md:justify-start pt-4 md:pt-0">
                <Button variant="ghost" size="icon" onClick={() => setViewMode('grid')} className={viewMode === 'grid' ? 'text-primary bg-primary/10' : 'text-slate-400'}>
                    <Grid className="h-5 w-5" />
                </Button>
                <Button variant="ghost" size="icon" onClick={() => setViewMode('list')} className={viewMode === 'list' ? 'text-primary bg-primary/10' : 'text-slate-400'}>
                    <ListCollapse className="h-5 w-5" />
                </Button>
            </div>
          </motion.div>

          {/* Tournaments Grid/List */}
          <AnimatePresence>
            {filteredTournaments.length > 0 ? (
              <motion.div 
                className={`grid gap-8 ${viewMode === 'grid' ? 'md:grid-cols-2 lg:grid-cols-3' : 'grid-cols-1'}`}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.5, delay: 0.4 }}
              >
                {filteredTournaments.map((tournament, index) => (
                  <MotionCard
                    key={tournament.id}
                    className="glassmorphic-card overflow-hidden group hover:shadow-neon transition-all duration-300 flex flex-col"
                    layout
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.9 }}
                    transition={{ duration: 0.3, delay: index * 0.05 }}
                  >
                    <CardHeader className={`p-0 relative ${viewMode === 'grid' ? '' : 'md:flex md:items-center'}`}>
                      <div className={`${viewMode === 'grid' ? 'aspect-video' : 'md:w-1/3 md:h-full md:aspect-video'} overflow-hidden`}>
                        <img  class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" alt={tournament.name} src="https://images.unsplash.com/photo-1651608593897-0d192e019b9e" />
                      </div>
                      <div className={`${viewMode === 'grid' ? 'absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent' : ''} ${viewMode === 'grid' ? 'p-4 bottom-0 left-0' : 'p-4 md:p-6 flex-1'}`}>
                        <CardTitle className={`font-bold ${viewMode === 'grid' ? 'text-2xl text-white' : 'text-xl text-slate-100'}`}>{tournament.name}</CardTitle>
                        <CardDescription className={`${viewMode === 'grid' ? 'text-slate-300' : 'text-slate-400 mt-1'}`}>{tournament.game}</CardDescription>
                      </div>
                    </CardHeader>
                    <CardContent className="p-6 space-y-3 flex-grow">
                      <div className="flex items-center text-sm text-slate-400">
                        <CalendarDays className="mr-2 h-5 w-5 text-accent" />
                        <span>Date: {tournament.date}</span>
                      </div>
                      <div className="flex items-center text-sm text-slate-400">
                        <Trophy className="mr-2 h-5 w-5 text-yellow-400" />
                        <span>Prize: {tournament.prize}</span>
                      </div>
                      <div className="flex items-center text-sm text-slate-400">
                        <Users className="mr-2 h-5 w-5 text-green-400" />
                        <span>Participants: {tournament.participants}/{tournament.slots}</span>
                      </div>
                       <div className="flex items-center text-sm text-slate-400">
                        <Filter className="mr-2 h-5 w-5 text-blue-400" />
                        <span>Type: {tournament.type}</span>
                      </div>
                       <div className="flex items-center text-sm">
                        <span className={`px-2 py-1 rounded-full text-xs font-semibold ${tournament.status === 'Open' ? 'bg-green-500/20 text-green-400' : tournament.status === 'Closed' ? 'bg-red-500/20 text-red-400' : 'bg-yellow-500/20 text-yellow-400'}`}>
                          Status: {tournament.status}
                        </span>
                      </div>
                    </CardContent>
                    <CardFooter className="p-6 pt-0 flex flex-col sm:flex-row justify-between items-center">
                      <Button asChild className="bg-primary/80 hover:bg-primary w-full sm:w-auto mb-2 sm:mb-0">
                        <Link to={`/tournaments/${tournament.id}`}>View Details</Link>
                      </Button>
                      {tournament.status === 'Open' && (
                        <Button variant="outline" className="border-accent text-accent hover:bg-accent/10 w-full sm:w-auto" onClick={() => handleRegister(tournament.name)}>
                          Register Now
                        </Button>
                      )}
                    </CardFooter>
                  </MotionCard>
                ))}
              </motion.div>
            ) : (
              <motion.div 
                className="text-center py-12"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
              >
                <Search className="h-16 w-16 text-slate-500 mx-auto mb-4" />
                <h3 className="text-2xl font-semibold text-slate-300 mb-2">No Tournaments Found</h3>
                <p className="text-slate-400">Try adjusting your search or filter criteria.</p>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      );
    };

    export default TournamentsPage;
  