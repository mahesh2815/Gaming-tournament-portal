
    import React, { createContext, useState, useContext, useEffect } from 'react';

    const AuthContext = createContext(null);

    export const AuthProvider = ({ children }) => {
      const [user, setUser] = useState(null);
      const [loading, setLoading] = useState(true);

      useEffect(() => {
        const storedUser = localStorage.getItem('currentUser');
        if (storedUser) {
          setUser(JSON.parse(storedUser));
        }
        setLoading(false);
      }, []);

      const login = (userData) => {
        localStorage.setItem('currentUser', JSON.stringify(userData));
        setUser(userData);
      };

      const logout = () => {
        localStorage.removeItem('currentUser');
        setUser(null);
      };

      const register = (userData) => {
        const users = JSON.parse(localStorage.getItem('users')) || [];
        const existingUser = users.find(u => u.email === userData.email);
        if (existingUser) {
          throw new Error('User with this email already exists.');
        }
        users.push(userData);
        localStorage.setItem('users', JSON.stringify(users));
      };
      

      return (
        <AuthContext.Provider value={{ user, login, logout, register, loading }}>
          {!loading && children}
        </AuthContext.Provider>
      );
    };

    export const useAuth = () => {
      const context = useContext(AuthContext);
      if (!context) {
        throw new Error('useAuth must be used within an AuthProvider');
      }
      return context;
    };
  