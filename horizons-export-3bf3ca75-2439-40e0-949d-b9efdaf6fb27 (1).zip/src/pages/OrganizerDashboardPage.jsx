
    import React, { useState, useEffect } from 'react';
    import { Button } from '@/components/ui/button';
    import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
    import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogTrigger, DialogClose } from "@/components/ui/dialog";
    import { useToast } from '@/components/ui/use-toast';
    import { motion } from 'framer-motion';
    import { Edit3, PlusCircle, Settings, Gamepad2, CalendarCheck2, Users } from 'lucide-react';
    import { useAuth } from '@/contexts/AuthContext';

    const MotionCard = motion(Card);
    
    const initialTournamentsData = [
        { id: 1, name: 'Valorant Vanguard Series', game: 'Valorant', date: '2025-08-10', prize: '$15,000', participants: 128, slots: 128, status: 'Open', type: 'Online', organizerEmail: 'admin@example.com' },
        { id: 2, name: 'League of Legends Championship', game: 'League of Legends', date: '2025-08-20', prize: '$20,000', participants: 60, slots: 64, status: 'Open', type: 'Online', organizerEmail: 'organizer@example.com' },
    ];

    const OrganizerDashboardPage = () => {
      const { user } = useAuth();
      const { toast } = useToast();
      const [tournaments, setTournaments] = useState([]);
      const [myTournaments, setMyTournaments] = useState([]);
      const [isFormOpen, setIsFormOpen] = useState(false);
      const [isEditing, setIsEditing] = useState(false);
      const [currentTournament, setCurrentTournament] = useState(null);

      const [tournamentName, setTournamentName] = useState('');
      const [game, setGame] = useState('');
      const [date, setDate] = useState('');
      const [prize, setPrize] = useState('');
      const [slots, setSlots] = useState('');
      const [type, setType] = useState('Online');
      const [status, setStatus] = useState('Upcoming');
      
      useEffect(() => {
        const storedTournaments = JSON.parse(localStorage.getItem('tournaments')) || initialTournamentsData;
        setTournaments(storedTournaments);
        if (user) {
            const filtered = storedTournaments.filter(t => t.organizerEmail === user.email || (user.role === 'admin' && !t.organizerEmail)); // Admins can see tournaments without specific organizer
            setMyTournaments(filtered);
        }
      }, [user]);

      const resetForm = () => {
        setTournamentName('');
        setGame('');
        setDate('');
        setPrize('');
        setSlots('');
        setType('Online');
        setStatus('Upcoming');
        setCurrentTournament(null);
        setIsEditing(false);
      };

      const handleAddTournament = () => {
        resetForm();
        setIsEditing(false);
        setIsFormOpen(true);
      };

      const handleEditTournament = (tournament) => {
        if (user.role !== 'admin' && tournament.organizerEmail !== user.email) {
          toast({ title: "Unauthorized", description: "You can only edit tournaments you created.", variant: "destructive"});
          return;
        }
        setIsEditing(true);
        setCurrentTournament(tournament);
        setTournamentName(tournament.name);
        setGame(tournament.game);
        setDate(tournament.date);
        setPrize(tournament.prize);
        setSlots(tournament.slots.toString());
        setType(tournament.type);
        setStatus(tournament.status);
        setIsFormOpen(true);
      };
      
      const handleFormSubmit = (e) => {
        e.preventDefault();
        if (!tournamentName || !game || !date || !prize || !slots) {
            toast({ title: "Error", description: "Please fill all required fields.", variant: "destructive" });
            return;
        }

        const newTournamentData = {
            id: isEditing ? currentTournament.id : Date.now(),
            name: tournamentName,
            game,
            date,
            prize,
            slots: parseInt(slots),
            participants: isEditing ? currentTournament.participants : 0,
            type,
            status,
            imgKey: `${game.toLowerCase().replace(/\s+/g, '-').replace(/[^\w-]+/g, '')}-tournament-art`,
            organizerEmail: user.email, // Assign current organizer
        };

        let updatedTournaments;
        if (isEditing) {
            updatedTournaments = tournaments.map(t => t.id === newTournamentData.id ? newTournamentData : t);
            toast({ title: "Tournament Updated", description: `${newTournamentData.name} has been updated.` });
        } else {
            updatedTournaments = [...tournaments, newTournamentData];
            toast({ title: "Tournament Created", description: `${newTournamentData.name} has been created.` });
        }
        setTournaments(updatedTournaments);
        localStorage.setItem('tournaments', JSON.stringify(updatedTournaments));
        
        const filtered = updatedTournaments.filter(t => t.organizerEmail === user.email || (user.role === 'admin' && !t.organizerEmail));
        setMyTournaments(filtered);

        resetForm();
        setIsFormOpen(false);
      };

      return (
        <div className="space-y-8">
          <motion.div
            initial={{ opacity: 0, y: -30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="flex flex-col sm:flex-row justify-between items-center"
          >
            <div>
              <h1 className="text-4xl md:text-5xl font-extrabold mb-2 text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent">
                <Settings className="inline-block mr-3 h-10 w-10 text-primary" />Organizer Dashboard
              </h1>
              <p className="text-lg text-slate-400">Manage your created tournaments and view participants.</p>
            </div>
             <Button onClick={handleAddTournament} className="mt-4 sm:mt-0 bg-gradient-to-r from-primary to-secondary hover:opacity-90 transition-opacity">
              <PlusCircle className="mr-2 h-5 w-5" /> Create New Tournament
            </Button>
          </motion.div>

          <Dialog open={isFormOpen} onOpenChange={setIsFormOpen}>
            <DialogContent className="sm:max-w-[525px] bg-slate-800 border-slate-700 text-slate-100">
              <DialogHeader>
                <DialogTitle className="text-2xl text-primary">{isEditing ? 'Edit Tournament' : 'Create New Tournament'}</DialogTitle>
                <DialogDescription className="text-slate-400">
                  {isEditing ? 'Update the details of your tournament.' : 'Fill in the details for your new tournament.'}
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleFormSubmit} className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="t-name-org" className="text-right text-slate-300">Name</Label>
                  <Input id="t-name-org" value={tournamentName} onChange={(e) => setTournamentName(e.target.value)} className="col-span-3 bg-slate-700/50 border-slate-600 focus:border-primary" />
                </div>
                 <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="t-game-org" className="text-right text-slate-300">Game</Label>
                  <Input id="t-game-org" value={game} onChange={(e) => setGame(e.target.value)} className="col-span-3 bg-slate-700/50 border-slate-600 focus:border-primary" />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="t-date-org" className="text-right text-slate-300">Date</Label>
                  <Input id="t-date-org" type="date" value={date} onChange={(e) => setDate(e.target.value)} className="col-span-3 bg-slate-700/50 border-slate-600 focus:border-primary" />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="t-prize-org" className="text-right text-slate-300">Prize</Label>
                  <Input id="t-prize-org" value={prize} onChange={(e) => setPrize(e.target.value)} className="col-span-3 bg-slate-700/50 border-slate-600 focus:border-primary" />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="t-slots-org" className="text-right text-slate-300">Slots</Label>
                  <Input id="t-slots-org" type="number" value={slots} onChange={(e) => setSlots(e.target.value)} className="col-span-3 bg-slate-700/50 border-slate-600 focus:border-primary" />
                </div>
                 <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="t-type-org" className="text-right text-slate-300">Type</Label>
                    <Select value={type} onValueChange={setType}>
                        <SelectTrigger id="t-type-org" className="col-span-3 bg-slate-700/50 border-slate-600 focus:border-primary">
                            <SelectValue placeholder="Select type" />
                        </SelectTrigger>
                        <SelectContent className="bg-slate-800 border-slate-700 text-slate-200">
                            <SelectItem value="Online">Online</SelectItem>
                            <SelectItem value="LAN">LAN</SelectItem>
                            <SelectItem value="In-Person">In-Person</SelectItem>
                        </SelectContent>
                    </Select>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="t-status-org" className="text-right text-slate-300">Status</Label>
                    <Select value={status} onValueChange={setStatus}>
                        <SelectTrigger id="t-status-org" className="col-span-3 bg-slate-700/50 border-slate-600 focus:border-primary">
                            <SelectValue placeholder="Select status" />
                        </SelectTrigger>
                        <SelectContent className="bg-slate-800 border-slate-700 text-slate-200">
                            <SelectItem value="Upcoming">Upcoming</SelectItem>
                            <SelectItem value="Open">Open</SelectItem>
                            <SelectItem value="Closed">Closed</SelectItem>
                             <SelectItem value="Ongoing">Ongoing</SelectItem>
                            <SelectItem value="Finished">Finished</SelectItem>
                        </SelectContent>
                    </Select>
                </div>
                <DialogFooter>
                   <DialogClose asChild>
                    <Button type="button" variant="outline" onClick={resetForm}>Cancel</Button>
                  </DialogClose>
                  <Button type="submit" className="bg-primary hover:bg-primary/90">{isEditing ? 'Save Changes' : 'Create Tournament'}</Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>

          <MotionCard 
            className="glassmorphic-card"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <CardHeader>
              <CardTitle className="text-2xl text-slate-100 flex items-center">
                <Gamepad2 className="mr-3 h-7 w-7 text-accent" /> My Tournaments
              </CardTitle>
              <CardDescription className="text-slate-400">View and manage tournaments you have organized.</CardDescription>
            </CardHeader>
            <CardContent className="max-h-[400px] overflow-y-auto">
              {myTournaments.length > 0 ? (
                <ul className="space-y-3">
                  {myTournaments.map(t => (
                    <li key={t.id} className="flex items-center justify-between p-3 bg-slate-700/30 rounded-md hover:bg-slate-700/50 transition-colors">
                      <div>
                        <p className="font-semibold text-slate-200">{t.name} <span className="text-xs text-slate-400">({t.game})</span></p>
                        <p className="text-sm text-slate-400">Date: {t.date} - Status: {t.status} - Participants: {t.participants}/{t.slots}</p>
                      </div>
                      <div className="space-x-2">
                        <Button variant="ghost" size="icon" className="text-blue-400 hover:text-blue-300" onClick={() => handleEditTournament(t)}>
                          <Edit3 className="h-5 w-5" />
                        </Button>
                         {/* Placeholder for participant view */}
                        <Button variant="ghost" size="icon" className="text-green-400 hover:text-green-300" onClick={() => toast({title: "Coming Soon!", description: "Participant management will be available soon."})}>
                          <Users className="h-5 w-5" />
                        </Button>
                         {/* Placeholder for results update */}
                        <Button variant="ghost" size="icon" className="text-yellow-400 hover:text-yellow-300" onClick={() => toast({title: "Coming Soon!", description: "Match results update will be available soon."})}>
                          <CalendarCheck2 className="h-5 w-5" />
                        </Button>
                      </div>
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="text-slate-400 text-center py-4">You haven't created any tournaments yet.</p>
              )}
            </CardContent>
          </MotionCard>
        </div>
      );
    };

    export default OrganizerDashboardPage;
  