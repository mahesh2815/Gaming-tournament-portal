
    import React, { useEffect, useState } from 'react';
    import { useParams, Link } from 'react-router-dom';
    import { Button } from '@/components/ui/button';
    import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
    import { Separator } from '@/components/ui/separator';
    import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
    import { motion } from 'framer-motion';
    import { CalendarDays, Trophy, Users, MapPin, Info, ListChecks, ShieldCheck, DollarSign, Gamepad2, ArrowLeft } from 'lucide-react';
    import { useToast } from '@/components/ui/use-toast';
    import NotFoundPage from '@/pages/NotFoundPage';

    const MotionCard = motion(Card);

    const initialTournaments = [
        { id: 1, name: 'Valorant Vanguard Series', game: 'Valorant', date: '2025-08-10', prize: '$15,000', participants: 128, slots: 128, status: 'Open', type: 'Online', imgKey: 'Valorant agent lineup wallpaper', description: 'Join the elite in the Valorant Vanguard Series! Compete for glory and a massive prize pool. Open to all skill levels.', rules: 'Standard competitive Valorant rules. Single elimination bracket. All matches Bo3, Finals Bo5.', schedule: 'Day 1: Rounds 1-3. Day 2: Quarterfinals & Semifinals. Day 3: Grand Finals.', prizes: '1st: $7,000, 2nd: $3,500, 3rd-4th: $1,500 each, 5th-8th: $500 each.', organizers: 'CyberMax Events', contact: 'events@cybermax.gg', location: 'Online / Global' },
        { id: 2, name: 'League of Legends Championship', game: 'League of Legends', date: '2025-08-20', prize: '$20,000', participants: 60, slots: 64, status: 'Open', type: 'Online', imgKey: 'League of Legends epic battle art', description: 'The ultimate LoL challenge. Form your team and fight for the championship title!', rules: '5v5 Summoner\'s Rift. Double elimination. Group stage followed by playoffs.', schedule: 'See website for full schedule. Qualifiers start Aug 1st.', prizes: '1st: $10,000, 2nd: $5,000, 3rd: $2,500.', organizers: 'Arena Esports', contact: 'lol@arenaesports.com', location: 'Online / EU West Server' },
    ];

    const TournamentDetailsPage = () => {
      const { id } = useParams();
      const [tournament, setTournament] = useState(null);
      const [loading, setLoading] = useState(true);
      const { toast } = useToast();

      useEffect(() => {
        const fetchTournament = () => {
          const storedTournaments = JSON.parse(localStorage.getItem('tournaments')) || initialTournaments;
          const foundTournament = storedTournaments.find(t => t.id.toString() === id);
          setTournament(foundTournament);
          setLoading(false);
        };
        fetchTournament();
      }, [id]);

      if (loading) {
        return <div className="flex justify-center items-center h-screen"><div className="animate-spin rounded-full h-32 w-32 border-t-2 border-b-2 border-primary"></div></div>;
      }

      if (!tournament) {
        return <NotFoundPage message="Tournament not found." />;
      }

      const handleRegistration = () => {
        toast({
          title: `Registered for ${tournament.name}!`,
          description: "Confirmation and details sent to your (mock) email.",
          variant: "default",
          duration: 5000,
        });
      };
      
      const { name, game, date, prize, participants, slots, status, type, description, rules, schedule, prizes, organizers, contact, location, imgKey } = tournament;

      return (
        <div className="space-y-8">
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="mb-6"
          >
            <Button variant="outline" asChild className="group hover:bg-primary/10">
              <Link to="/tournaments" className="text-sm text-primary">
                <ArrowLeft className="mr-2 h-4 w-4 group-hover:text-primary-foreground" />
                Back to Tournaments
              </Link>
            </Button>
          </motion.div>

          <header className="relative rounded-xl overflow-hidden shadow-2xl h-80 md:h-96">
            <img  class="absolute inset-0 w-full h-full object-cover" alt={`${name} promotional image`} src="https://images.unsplash.com/photo-1684347417348-d261d03c60ef" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/50 to-transparent"></div>
            <div className="absolute bottom-0 left-0 p-6 md:p-10">
              <motion.h1 
                className="text-4xl md:text-6xl font-extrabold text-white mb-2"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
              >
                {name}
              </motion.h1>
              <motion.p 
                className="text-xl md:text-2xl text-primary font-semibold"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.4 }}
              >
                <Gamepad2 className="inline-block mr-2 h-6 w-6" /> {game}
              </motion.p>
            </div>
          </header>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="md:col-span-2 space-y-8">
              <MotionCard 
                className="glassmorphic-card"
                initial={{ opacity: 0, x: -50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5, delay: 0.2 }}
              >
                <CardHeader>
                  <CardTitle className="text-3xl font-semibold text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent flex items-center">
                    <Info className="mr-3 h-8 w-8" /> Tournament Overview
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-slate-300 leading-relaxed">{description}</p>
                </CardContent>
              </MotionCard>

              <Tabs defaultValue="rules" className="w-full">
                <TabsList className="grid w-full grid-cols-2 md:grid-cols-4 gap-2 bg-slate-800/50 p-2 rounded-lg">
                  <TabsTrigger value="rules" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">Rules</TabsTrigger>
                  <TabsTrigger value="schedule" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">Schedule</TabsTrigger>
                  <TabsTrigger value="prizes" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">Prizes</TabsTrigger>
                  <TabsTrigger value="contact" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">Contact</TabsTrigger>
                </TabsList>
                <Separator className="my-4" />
                <MotionCard 
                  className="glassmorphic-card mt-4"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5 }}
                >
                  <CardContent className="pt-6">
                    <TabsContent value="rules">
                      <h3 className="text-xl font-semibold mb-3 text-slate-100 flex items-center"><ListChecks className="mr-2 h-6 w-6 text-primary"/>Rules & Format</h3>
                      <p className="text-slate-400 whitespace-pre-line">{rules || "Detailed rules will be announced soon."}</p>
                    </TabsContent>
                    <TabsContent value="schedule">
                      <h3 className="text-xl font-semibold mb-3 text-slate-100 flex items-center"><CalendarDays className="mr-2 h-6 w-6 text-primary"/>Event Schedule</h3>
                      <p className="text-slate-400 whitespace-pre-line">{schedule || "Full schedule coming soon."}</p>
                    </TabsContent>
                    <TabsContent value="prizes">
                      <h3 className="text-xl font-semibold mb-3 text-slate-100 flex items-center"><DollarSign className="mr-2 h-6 w-6 text-primary"/>Prize Distribution</h3>
                      <p className="text-slate-400 whitespace-pre-line">{prizes || "Prize details will be updated."}</p>
                    </TabsContent>
                    <TabsContent value="contact">
                      <h3 className="text-xl font-semibold mb-3 text-slate-100">Organizer & Contact</h3>
                      <p className="text-slate-400"><strong>Organizer:</strong> {organizers || "TBA"}</p>
                      <p className="text-slate-400"><strong>Contact:</strong> <a href={`mailto:${contact}`} className="text-accent hover:underline">{contact || "TBA"}</a></p>
                    </TabsContent>
                  </CardContent>
                </MotionCard>
              </Tabs>
            </div>

            <aside className="space-y-8">
              <MotionCard 
                className="glassmorphic-card"
                initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5, delay: 0.3 }}
              >
                <CardHeader>
                  <CardTitle className="text-2xl font-semibold text-slate-100">Key Details</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-start">
                    <CalendarDays className="h-6 w-6 text-accent mr-3 mt-1 flex-shrink-0" />
                    <div>
                      <p className="font-semibold text-slate-300">Date</p>
                      <p className="text-slate-400">{date}</p>
                    </div>
                  </div>
                  <Separator />
                  <div className="flex items-start">
                    <Trophy className="h-6 w-6 text-yellow-400 mr-3 mt-1 flex-shrink-0" />
                    <div>
                      <p className="font-semibold text-slate-300">Prize Pool</p>
                      <p className="text-slate-400">{prize}</p>
                    </div>
                  </div>
                  <Separator />
                  <div className="flex items-start">
                    <Users className="h-6 w-6 text-green-400 mr-3 mt-1 flex-shrink-0" />
                    <div>
                      <p className="font-semibold text-slate-300">Participants</p>
                      <p className="text-slate-400">{participants} / {slots}</p>
                    </div>
                  </div>
                  <Separator />
                  <div className="flex items-start">
                    <ShieldCheck className="h-6 w-6 text-blue-400 mr-3 mt-1 flex-shrink-0" />
                    <div>
                      <p className="font-semibold text-slate-300">Status</p>
                      <p className={`font-bold ${status === 'Open' ? 'text-green-400' : status === 'Closed' ? 'text-red-400' : 'text-yellow-400'}`}>{status}</p>
                    </div>
                  </div>
                  <Separator />
                  <div className="flex items-start">
                    <MapPin className="h-6 w-6 text-purple-400 mr-3 mt-1 flex-shrink-0" />
                    <div>
                      <p className="font-semibold text-slate-300">Type / Location</p>
                      <p className="text-slate-400">{type} / {location}</p>
                    </div>
                  </div>
                  
                  {status === 'Open' && (
                    <>
                      <Separator />
                      <Button 
                        size="lg" 
                        className="w-full bg-gradient-to-r from-primary to-secondary hover:opacity-90 transition-opacity transform hover:scale-105 mt-4"
                        onClick={handleRegistration}
                      >
                        Register Now
                      </Button>
                    </>
                  )}
                  {status === 'Closed' && (
                    <Button size="lg" className="w-full mt-4" disabled>Registration Closed</Button>
                  )}
                   {status === 'Upcoming' && (
                    <Button size="lg" className="w-full mt-4" variant="outline">Notify Me When Open</Button>
                  )}
                </CardContent>
              </MotionCard>
            </aside>
          </div>
        </div>
      );
    };

    export default TournamentDetailsPage;
  