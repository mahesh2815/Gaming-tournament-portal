
    import React, { useState } from 'react';
    import { Link, useNavigate } from 'react-router-dom';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
    import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
    import { useToast } from '@/components/ui/use-toast';
    import { motion } from 'framer-motion';
    import { UserPlus, Mail, Lock, Eye, EyeOff, Shield, UserCog, User } from 'lucide-react';
    import { useAuth } from '@/contexts/AuthContext';

    const MotionCard = motion(Card);

    const RegisterPage = () => {
      const [username, setUsername] = useState('');
      const [email, setEmail] = useState('');
      const [password, setPassword] = useState('');
      const [confirmPassword, setConfirmPassword] = useState('');
      const [role, setRole] = useState('player');
      const [showPassword, setShowPassword] = useState(false);
      const [showConfirmPassword, setShowConfirmPassword] = useState(false);
      const [error, setError] = useState('');
      const { toast } = useToast();
      const navigate = useNavigate();
      const { register: registerUser } = useAuth();

      const handleSubmit = (e) => {
        e.preventDefault();
        setError('');

        if (!username || !email || !password || !confirmPassword || !role) {
          setError('All fields are required.');
          return;
        }
        if (password !== confirmPassword) {
          setError('Passwords do not match.');
          return;
        }
        if (password.length < 6) {
          setError('Password must be at least 6 characters long.');
          return;
        }

        try {
          registerUser({ username, email, password, role });
          toast({
            title: "Registration Successful!",
            description: `Welcome, ${username}! Your account as a ${role} has been created. You can now log in.`,
            variant: "default",
          });
          navigate('/login');
        } catch (err) {
          setError(err.message);
          toast({
            title: "Registration Failed",
            description: err.message,
            variant: "destructive",
          });
        }
      };

      return (
        <div className="flex items-center justify-center min-h-[calc(100vh-10rem)] py-12">
          <MotionCard 
            className="w-full max-w-md glassmorphic-card"
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, ease: "easeOut" }}
          >
            <CardHeader className="text-center">
              <UserPlus className="mx-auto h-16 w-16 text-primary mb-4" />
              <CardTitle className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent">Create Account</CardTitle>
              <CardDescription className="text-slate-400">Join GameForge and start competing!</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="username" className="text-slate-300">Username</Label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-slate-400" />
                    <Input 
                      id="username" 
                      type="text" 
                      placeholder="Choose a username" 
                      value={username} 
                      onChange={(e) => setUsername(e.target.value)} 
                      className="pl-10 bg-slate-700/50 border-slate-600 focus:border-primary text-slate-100" 
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-slate-300">Email</Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-slate-400" />
                    <Input 
                      id="email" 
                      type="email" 
                      placeholder="your@email.com" 
                      value={email} 
                      onChange={(e) => setEmail(e.target.value)} 
                      className="pl-10 bg-slate-700/50 border-slate-600 focus:border-primary text-slate-100" 
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="password" className="text-slate-300">Password</Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-slate-400" />
                    <Input 
                      id="password" 
                      type={showPassword ? "text" : "password"} 
                      placeholder="Create a password" 
                      value={password} 
                      onChange={(e) => setPassword(e.target.value)} 
                      className="pl-10 pr-10 bg-slate-700/50 border-slate-600 focus:border-primary text-slate-100" 
                    />
                    <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 transform -translate-y-1/2 text-slate-400 hover:text-primary">
                      {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                    </button>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="confirm-password" className="text-slate-300">Confirm Password</Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-slate-400" />
                    <Input 
                      id="confirm-password" 
                      type={showConfirmPassword ? "text" : "password"} 
                      placeholder="Confirm your password" 
                      value={confirmPassword} 
                      onChange={(e) => setConfirmPassword(e.target.value)} 
                      className="pl-10 pr-10 bg-slate-700/50 border-slate-600 focus:border-primary text-slate-100" 
                    />
                     <button type="button" onClick={() => setShowConfirmPassword(!showConfirmPassword)} className="absolute right-3 top-1/2 transform -translate-y-1/2 text-slate-400 hover:text-primary">
                      {showConfirmPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                    </button>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="role" className="text-slate-300">Register as</Label>
                  <Select value={role} onValueChange={setRole}>
                    <SelectTrigger id="role" className="w-full bg-slate-700/50 border-slate-600 focus:border-primary text-slate-100">
                      <SelectValue placeholder="Select your role" />
                    </SelectTrigger>
                    <SelectContent className="bg-slate-800 border-slate-700 text-slate-200">
                      <SelectItem value="player"><div className="flex items-center"><User className="mr-2 h-4 w-4" /> Player</div></SelectItem>
                      <SelectItem value="organizer"><div className="flex items-center"><UserCog className="mr-2 h-4 w-4" /> Organizer</div></SelectItem>
                      <SelectItem value="admin"><div className="flex items-center"><Shield className="mr-2 h-4 w-4" /> Admin</div></SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                {error && <p className="text-sm text-red-400">{error}</p>}
                <Button type="submit" className="w-full bg-gradient-to-r from-primary to-secondary hover:opacity-90 transition-opacity text-lg py-6">
                  Register
                </Button>
              </form>
            </CardContent>
            <CardFooter className="text-center">
              <p className="text-sm text-slate-400 w-full">
                Already have an account?{' '}
                <Link to="/login" className="font-medium text-primary hover:underline">
                  Log in here
                </Link>
              </p>
            </CardFooter>
          </MotionCard>
        </div>
      );
    };

    export default RegisterPage;
  