
    import React, { useState } from 'react';
    import { Link, NavLink, useNavigate } from 'react-router-dom';
    import { Gamepad2, Menu, X, Sun, Moon, Swords, Trophy, Users, LogOut, Shield, Settings } from 'lucide-react';
    import { Button } from '@/components/ui/button';
    import { motion, AnimatePresence } from 'framer-motion';
    import { useTheme } from '@/components/ThemeProvider';
    import { useAuth } from '@/contexts/AuthContext';
    import {
      DropdownMenu,
      DropdownMenuContent,
      DropdownMenuItem,
      DropdownMenuLabel,
      DropdownMenuSeparator,
      DropdownMenuTrigger,
    } from "@/components/ui/dropdown-menu";
    import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

    const NavItem = ({ to, children, icon, onClick }) => {
      const IconComponent = icon;
      return (
        <NavLink
          to={to}
          onClick={onClick}
          className={({ isActive }) =>
            `flex items-center px-3 py-2 rounded-md text-sm font-medium transition-all duration-300 ease-in-out
            ${isActive 
              ? 'bg-primary/20 text-primary shadow-neon' 
              : 'text-slate-300 hover:bg-slate-700 hover:text-white'
            }`
          }
        >
          {IconComponent && <IconComponent className="mr-2 h-5 w-5" />}
          {children}
        </NavLink>
      );
    };

    const MobileNavItem = ({ to, children, icon, onClick }) => {
      const IconComponent = icon;
      return (
        <NavLink
          to={to}
          onClick={onClick}
          className={({ isActive }) =>
            `block px-3 py-3 rounded-md text-base font-medium transition-colors duration-200
            ${isActive 
              ? 'bg-primary text-primary-foreground' 
              : 'text-slate-200 hover:bg-slate-700 hover:text-white'
            }`
          }
        >
          {IconComponent && <IconComponent className="inline-block mr-3 h-5 w-5" />}
          {children}
        </NavLink>
      );
    };
    
    const Navbar = () => {
      const [isOpen, setIsOpen] = useState(false);
      const { theme, setTheme } = useTheme();
      const { user, logout } = useAuth();
      const navigate = useNavigate();

      const toggleNavbar = () => setIsOpen(!isOpen);
      const closeMobileMenu = () => setIsOpen(false);

      const handleLogout = () => {
        logout();
        closeMobileMenu();
        navigate('/');
      };

      const navLinks = [
        { to: "/", label: "Home", icon: Gamepad2 },
        { to: "/tournaments", label: "Tournaments", icon: Swords },
        { to: "/leaderboards", label: "Leaderboards", icon: Trophy },
      ];

      const adminNavLinks = [
        { to: "/admin", label: "Admin Panel", icon: Shield },
      ];
      
      const organizerNavLinks = [
         { to: "/organizer", label: "Organizer Panel", icon: Settings },
      ];

      const getInitials = (name) => {
        if (!name) return "??";
        const names = name.split(' ');
        if (names.length === 1) return names[0].substring(0, 2).toUpperCase();
        return names[0][0].toUpperCase() + names[names.length - 1][0].toUpperCase();
      }

      return (
        <nav className="bg-slate-800/50 backdrop-blur-lg shadow-lg sticky top-0 z-50 border-b border-slate-700">
          <div className="container mx-auto px-4">
            <div className="flex items-center justify-between h-20">
              <Link to="/" className="flex items-center space-x-2 group">
                <Gamepad2 className="h-10 w-10 text-primary group-hover:animate-pulse-glow transition-all duration-300" />
                <span className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary group-hover:opacity-80 transition-opacity">
                  GameForge
                </span>
              </Link>
    
              <div className="hidden md:flex items-center space-x-4">
                {navLinks.map(link => (
                  <NavItem key={link.to} to={link.to} icon={link.icon}>{link.label}</NavItem>
                ))}
                {user?.role === 'admin' && adminNavLinks.map(link => (
                  <NavItem key={link.to} to={link.to} icon={link.icon}>{link.label}</NavItem>
                ))}
                 {user?.role === 'organizer' && organizerNavLinks.map(link => (
                  <NavItem key={link.to} to={link.to} icon={link.icon}>{link.label}</NavItem>
                ))}
              </div>
    
              <div className="hidden md:flex items-center space-x-3">
                {user ? (
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" className="relative h-10 w-10 rounded-full">
                        <Avatar className="h-9 w-9">
                          <AvatarImage src={`https://avatar.vercel.sh/${user.username}.png?size=40`} alt={user.username} />
                          <AvatarFallback className="bg-primary text-primary-foreground">{getInitials(user.username)}</AvatarFallback>
                        </Avatar>
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent className="w-56 bg-slate-800 border-slate-700 text-slate-200" align="end" forceMount>
                      <DropdownMenuLabel className="font-normal">
                        <div className="flex flex-col space-y-1">
                          <p className="text-sm font-medium leading-none text-slate-50">{user.username}</p>
                          <p className="text-xs leading-none text-slate-400">{user.email}</p>
                        </div>
                      </DropdownMenuLabel>
                      <DropdownMenuSeparator className="bg-slate-700"/>
                      <DropdownMenuItem className="hover:bg-slate-700/50 focus:bg-slate-700/50" onSelect={() => navigate('/profile')}> {/* Placeholder */}
                        <Users className="mr-2 h-4 w-4" />
                        <span>Profile</span>
                      </DropdownMenuItem>
                      <DropdownMenuItem className="hover:bg-slate-700/50 focus:bg-slate-700/50" onSelect={handleLogout}>
                        <LogOut className="mr-2 h-4 w-4" />
                        <span>Log out</span>
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                ) : (
                  <>
                    <Button variant="outline" size="sm" asChild>
                      <Link to="/login">Login</Link>
                    </Button>
                    <Button size="sm" asChild className="bg-gradient-to-r from-primary to-secondary hover:opacity-90 transition-opacity">
                      <Link to="/register">Sign Up</Link>
                    </Button>
                  </>
                )}
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
                  aria-label="Toggle theme"
                  className="text-slate-300 hover:text-primary"
                >
                  {theme === 'dark' ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
                </Button>
              </div>
    
              <div className="md:hidden flex items-center">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
                  aria-label="Toggle theme"
                  className="text-slate-300 hover:text-primary mr-2"
                >
                  {theme === 'dark' ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
                </Button>
                <Button
                  onClick={toggleNavbar}
                  variant="ghost"
                  size="icon"
                  className="text-slate-300 hover:text-primary"
                  aria-label="Toggle navigation"
                >
                  {isOpen ? <X className="h-7 w-7" /> : <Menu className="h-7 w-7" />}
                </Button>
              </div>
            </div>
          </div>
    
          <AnimatePresence>
            {isOpen && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: 0.3, ease: "easeInOut" }}
                className="md:hidden bg-slate-800/80 backdrop-blur-md absolute w-full"
              >
                <div className="px-2 pt-2 pb-3 space-y-2 sm:px-3">
                  {navLinks.map(link => (
                    <MobileNavItem key={link.to} to={link.to} icon={link.icon} onClick={closeMobileMenu}>{link.label}</MobileNavItem>
                  ))}
                   {user?.role === 'admin' && adminNavLinks.map(link => (
                    <MobileNavItem key={link.to} to={link.to} icon={link.icon} onClick={closeMobileMenu}>{link.label}</MobileNavItem>
                  ))}
                  {user?.role === 'organizer' && organizerNavLinks.map(link => (
                    <MobileNavItem key={link.to} to={link.to} icon={link.icon} onClick={closeMobileMenu}>{link.label}</MobileNavItem>
                  ))}

                  <div className="pt-4 border-t border-slate-700">
                    {user ? (
                      <>
                        <MobileNavItem to="/profile" icon={Users} onClick={closeMobileMenu}>Profile</MobileNavItem>
                        <button
                          onClick={handleLogout}
                          className="w-full text-left block px-3 py-3 rounded-md text-base font-medium text-slate-200 hover:bg-slate-700 hover:text-white"
                        >
                         <LogOut className="inline-block mr-3 h-5 w-5" /> Logout
                        </button>
                      </>
                    ) : (
                      <>
                        <MobileNavItem to="/login" icon={Users} onClick={closeMobileMenu}>Login</MobileNavItem>
                        <MobileNavItem to="/register" icon={Users} onClick={closeMobileMenu}>Sign Up</MobileNavItem>
                      </>
                    )}
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </nav>
      );
    };
    
    export default Navbar;
  