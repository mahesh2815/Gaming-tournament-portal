
    import React, { useState } from 'react';
    import { Link, useNavigate } from 'react-router-dom';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
    import { useToast } from '@/components/ui/use-toast';
    import { motion } from 'framer-motion';
    import { LogIn, Mail, Lock, Eye, EyeOff } from 'lucide-react';
    import { useAuth } from '@/contexts/AuthContext';

    const MotionCard = motion(Card);

    const LoginPage = () => {
      const [email, setEmail] = useState('');
      const [password, setPassword] = useState('');
      const [showPassword, setShowPassword] = useState(false);
      const [error, setError] = useState('');
      const { toast } = useToast();
      const navigate = useNavigate();
      const { login } = useAuth();

      const handleSubmit = (e) => {
        e.preventDefault();
        setError('');

        if (!email || !password) {
          setError('Email and password are required.');
          return;
        }

        const users = JSON.parse(localStorage.getItem('users')) || [];
        const user = users.find(u => u.email === email && u.password === password); 

        if (user) {
          login(user);
          toast({
            title: "Login Successful!",
            description: `Welcome back, ${user.username}!`,
          });
          
          if (user.role === 'admin') {
            navigate('/admin');
          } else if (user.role === 'organizer') {
            navigate('/organizer');
          } else {
            navigate('/');
          }

        } else {
          setError('Invalid email or password.');
          toast({
            title: "Login Failed",
            description: "Invalid email or password. Please try again.",
            variant: "destructive",
          });
        }
      };

      return (
        <div className="flex items-center justify-center min-h-[calc(100vh-10rem)] py-12">
          <MotionCard 
            className="w-full max-w-md glassmorphic-card"
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, ease: "easeOut" }}
          >
            <CardHeader className="text-center">
              <LogIn className="mx-auto h-16 w-16 text-primary mb-4" />
              <CardTitle className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent">Welcome Back</CardTitle>
              <CardDescription className="text-slate-400">Log in to access your account and tournaments.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-slate-300">Email</Label>
                   <div className="relative">
                    <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-slate-400" />
                    <Input 
                      id="email" 
                      type="email" 
                      placeholder="your@email.com" 
                      value={email} 
                      onChange={(e) => setEmail(e.target.value)} 
                      className="pl-10 bg-slate-700/50 border-slate-600 focus:border-primary text-slate-100" 
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="password" className="text-slate-300">Password</Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-slate-400" />
                    <Input 
                      id="password" 
                      type={showPassword ? "text" : "password"} 
                      placeholder="Enter your password" 
                      value={password} 
                      onChange={(e) => setPassword(e.target.value)} 
                      className="pl-10 pr-10 bg-slate-700/50 border-slate-600 focus:border-primary text-slate-100" 
                    />
                     <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 transform -translate-y-1/2 text-slate-400 hover:text-primary">
                      {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                    </button>
                  </div>
                  <div className="text-right">
                    <Link to="#" className="text-xs text-primary hover:underline">Forgot password?</Link>
                  </div>
                </div>
                {error && <p className="text-sm text-red-400">{error}</p>}
                <Button type="submit" className="w-full bg-gradient-to-r from-primary to-secondary hover:opacity-90 transition-opacity text-lg py-6">
                  Log In
                </Button>
              </form>
            </CardContent>
            <CardFooter className="text-center">
              <p className="text-sm text-slate-400 w-full">
                Don't have an account?{' '}
                <Link to="/register" className="font-medium text-primary hover:underline">
                  Sign up now
                </Link>
              </p>
            </CardFooter>
          </MotionCard>
        </div>
      );
    };

    export default LoginPage;
  