
    import React, { useState, useEffect } from 'react';
    import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
    import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
    import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
    import { Trophy, Star, Users, Medal } from 'lucide-react';
    import { motion } from 'framer-motion';

    const MotionCard = motion(Card);

    const dummyLeaderboards = {
      'Valorant': [
        { rank: 1, name: 'ShadowStriker', score: 5200, team: 'Team Phantom', avatarText: 'SS' },
        { rank: 2, name: 'ViperAce', score: 4950, team: 'Serpent Squad', avatarText: 'VA' },
        { rank: 3, name: 'JettStream', score: 4800, team: 'Cloud Warriors', avatarText: 'JS' },
        { rank: 4, name: 'CypherLogic', score: 4700, team: 'Code Breakers', avatarText: 'CL' },
        { rank: 5, name: 'ReynaReaper', score: 4650, team: 'Soul Harvest', avatarText: 'RR' },
      ],
      'League of Legends': [
        { rank: 1, name: 'BaronSlayer', score: 6100, team: 'Nexus Kings', avatarText: 'BS' },
        { rank: 2, name: 'MidOrFeed', score: 5900, team: 'Lane Dominators', avatarText: 'MF' },
        { rank: 3, name: 'JungleKing', score: 5850, team: 'Wild Stalkers', avatarText: 'JK' },
        { rank: 4, name: 'ADC Prodigy', score: 5700, team: 'Marksmen United', avatarText: 'AP' },
        { rank: 5, name: 'SupportGod', score: 5600, team: 'Guardian Angels', avatarText: 'SG' },
      ],
      'Counter-Strike: GO': [
        { rank: 1, name: 'HeadshotMaster', score: 7500, team: 'Aimers Elite', avatarText: 'HM' },
        { rank: 2, name: 'ClutchKing', score: 7200, team: 'Endgame Heroes', avatarText: 'CK' },
        { rank: 3, name: 'AWP GOD', score: 7150, team: 'One Shot Inc.', avatarText: 'AG' },
        { rank: 4, name: 'Smoker', score: 6900, team: 'Tactical Experts', avatarText: 'SM' },
        { rank: 5, name: 'EntryFragger', score: 6850, team: 'Breach Squad', avatarText: 'EF' },
      ],
    };
    const games = Object.keys(dummyLeaderboards);

    const LeaderboardsPage = () => {
      const [selectedGame, setSelectedGame] = useState(games[0]);
      const [leaderboardData, setLeaderboardData] = useState([]);

      useEffect(() => {
        // Simulate API call or data fetching
        setLeaderboardData(dummyLeaderboards[selectedGame] || []);
      }, [selectedGame]);

      const getRankColor = (rank) => {
        if (rank === 1) return 'text-yellow-400';
        if (rank === 2) return 'text-slate-300';
        if (rank === 3) return 'text-orange-400';
        return 'text-slate-400';
      };

      const getRankIcon = (rank) => {
        if (rank === 1) return <Trophy className="h-6 w-6 text-yellow-400" />;
        if (rank === 2) return <Medal className="h-6 w-6 text-slate-300" />;
        if (rank === 3) return <Star className="h-6 w-6 text-orange-400" />;
        return <span className={`font-bold text-lg ${getRankColor(rank)}`}>{rank}</span>;
      }

      return (
        <div className="space-y-8">
          <motion.div
            initial={{ opacity: 0, y: -30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-4xl md:text-5xl font-extrabold text-center mb-4 text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent">
              <Trophy className="inline-block mr-4 h-12 w-12 text-primary" />
              Global Leaderboards
            </h1>
            <p className="text-lg text-slate-400 text-center mb-10 max-w-2xl mx-auto">
              See who's topping the charts in your favorite games. Glory awaits the best!
            </p>
          </motion.div>

          <motion.div 
            className="flex flex-col sm:flex-row justify-center items-center mb-8 space-y-4 sm:space-y-0 sm:space-x-4"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <label htmlFor="game-select" className="text-lg font-medium text-slate-300">Select Game:</label>
            <Select value={selectedGame} onValueChange={setSelectedGame}>
              <SelectTrigger id="game-select" className="w-full sm:w-[250px] bg-slate-700/50 border-slate-600 text-slate-100">
                <SelectValue placeholder="Choose a game" />
              </SelectTrigger>
              <SelectContent className="bg-slate-800 border-slate-700 text-slate-200">
                {games.map(game => (
                  <SelectItem key={game} value={game}>{game}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </motion.div>

          <MotionCard 
            className="glassmorphic-card"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, delay: 0.4 }}
          >
            <CardHeader>
              <CardTitle className="text-2xl font-semibold text-slate-100 flex items-center">
                Top Players: {selectedGame}
                <Users className="ml-3 h-7 w-7 text-accent" />
              </CardTitle>
            </CardHeader>
            <CardContent>
              {leaderboardData.length > 0 ? (
                <ul className="space-y-4">
                  {leaderboardData.map((player, index) => (
                    <motion.li
                      key={player.rank}
                      className={`flex items-center p-4 rounded-lg transition-all duration-300 ease-in-out
                        ${index === 0 ? 'bg-primary/30 border-2 border-primary shadow-neon' : 
                        index === 1 ? 'bg-slate-700/60 border border-slate-600' :
                        index === 2 ? 'bg-slate-700/40 border border-slate-600/70' :
                        'bg-slate-800/50 border border-slate-700/50 hover:bg-slate-700/70'}`}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ duration: 0.3, delay: 0.1 * index }}
                    >
                      <div className="w-12 text-center mr-4 flex items-center justify-center">
                        {getRankIcon(player.rank)}
                      </div>
                      <Avatar className="h-12 w-12 mr-4 border-2 border-primary/50">
                        <AvatarImage src={`https://avatar.vercel.sh/${player.name}.png?size=128`} alt={player.name} />
                        <AvatarFallback className="bg-slate-600 text-slate-100 font-bold">{player.avatarText}</AvatarFallback>
                      </Avatar>
                      <div className="flex-grow">
                        <h3 className={`text-lg font-semibold ${index < 3 ? 'text-slate-100' : 'text-slate-200'}`}>{player.name}</h3>
                        <p className="text-sm text-slate-400">{player.team || 'No Team'}</p>
                      </div>
                      <div className="text-right">
                        <p className={`text-xl font-bold ${getRankColor(player.rank)}`}>{player.score}</p>
                        <p className="text-xs text-slate-500">Points</p>
                      </div>
                    </motion.li>
                  ))}
                </ul>
              ) : (
                <p className="text-center text-slate-400 py-8">No leaderboard data available for {selectedGame}.</p>
              )}
            </CardContent>
          </MotionCard>
        </div>
      );
    };

    export default LeaderboardsPage;
  