
    import React from 'react';
    import { Link } from 'react-router-dom';
    import { Gamepad2, Twitter, Facebook, Instagram } from 'lucide-react';

    const Footer = () => {
      const currentYear = new Date().getFullYear();
      const socialLinks = [
        { icon: Twitter, href: "#", label: "Twitter" },
        { icon: Facebook, href: "#", label: "Facebook" },
        { icon: Instagram, href: "#", label: "Instagram" },
      ];

      return (
        <footer className="bg-slate-800/30 border-t border-slate-700 text-slate-400 py-12">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div>
                <Link to="/" className="flex items-center space-x-2 mb-4">
                  <Gamepad2 className="h-8 w-8 text-primary" />
                  <span className="text-xl font-bold text-slate-200">GameForge</span>
                </Link>
                <p className="text-sm">
                  Your ultimate destination for gaming tournaments. Join, compete, and conquer!
                </p>
              </div>

              <div>
                <h5 className="text-lg font-semibold text-slate-200 mb-4">Quick Links</h5>
                <ul className="space-y-2">
                  <li><Link to="/tournaments" className="hover:text-primary transition-colors">Tournaments</Link></li>
                  <li><Link to="/leaderboards" className="hover:text-primary transition-colors">Leaderboards</Link></li>
                  <li><Link to="/register" className="hover:text-primary transition-colors">Register</Link></li>
                  <li><Link to="/login" className="hover:text-primary transition-colors">Login</Link></li>
                </ul>
              </div>

              <div>
                <h5 className="text-lg font-semibold text-slate-200 mb-4">Connect With Us</h5>
                <div className="flex space-x-4">
                  {socialLinks.map(link => (
                    <a key={link.label} href={link.href} aria-label={link.label} className="hover:text-primary transition-colors">
                      <link.icon className="h-6 w-6" />
                    </a>
                  ))}
                </div>
                <p className="text-sm mt-4">
                  Stay updated with the latest news and events.
                </p>
              </div>
            </div>

            <div className="mt-12 border-t border-slate-700 pt-8 text-center">
              <p className="text-sm">
                &copy; {currentYear} GameForge. All rights reserved.
              </p>
              <p className="text-xs mt-1">
                Built with passion by Hostinger Horizons.
              </p>
            </div>
          </div>
        </footer>
      );
    };

    export default Footer;
  