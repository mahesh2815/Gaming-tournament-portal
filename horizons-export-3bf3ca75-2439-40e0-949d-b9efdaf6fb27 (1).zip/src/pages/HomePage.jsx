
    import React from 'react';
    import { Link } from 'react-router-dom';
    import { Button } from '@/components/ui/button';
    import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
    import { motion } from 'framer-motion';
    import { PlayCircle, CalendarDays, Trophy, Users, Zap } from 'lucide-react';
    import { useToast } from '@/components/ui/use-toast';

    const MotionCard = motion(Card);

    const HomePage = () => {
      const { toast } = useToast();

      const featuredTournaments = [
        { id: 1, name: 'CyberClash 2025: Valorant', game: 'Valorant', date: '2025-06-15', prize: '$10,000', imgKey: 'Valorant tournament poster' },
        { id: 2, name: 'Apex Legends Arena', game: 'Apex Legends', date: '2025-07-01', prize: '$5,000', imgKey: 'Apex Legends game characters' },
        { id: 3, name: 'Fortnite Fusion Fest', game: 'Fortnite', date: '2025-07-20', prize: '$7,500', imgKey: 'Fortnite battle scene' },
      ];

      const handleNotify = (tournamentName) => {
        toast({
          title: "Notification Subscribed!",
          description: `You'll be notified about ${tournamentName}.`,
          duration: 3000,
        });
      };

      return (
        <div className="space-y-16">
          {/* Hero Section */}
          <motion.section
            initial={{ opacity: 0, y: -50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="relative text-center py-20 px-6 rounded-xl overflow-hidden bg-gradient-hero shadow-2xl"
          >
            <div className="absolute inset-0 bg-black/40 z-0"></div>
            <div className="relative z-10">
              <motion.h1 
                className="text-5xl md:text-7xl font-extrabold mb-6 text-transparent bg-clip-text bg-gradient-to-r from-slate-100 via-slate-200 to-slate-400"
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5, delay: 0.3 }}
              >
                Join the Elite. Conquer the Arena.
              </motion.h1>
              <motion.p 
                className="text-xl md:text-2xl text-slate-300 mb-10 max-w-3xl mx-auto"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.5 }}
              >
                Discover, compete, and dominate in the most thrilling gaming tournaments. Your legacy starts here.
              </motion.p>
              <motion.div 
                className="space-x-4"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.7 }}
              >
                <Button size="lg" asChild className="bg-gradient-to-r from-primary to-secondary hover:opacity-90 transition-opacity transform hover:scale-105 shadow-lg">
                  <Link to="/tournaments">
                    <PlayCircle className="mr-2 h-6 w-6" /> Find Tournaments
                  </Link>
                </Button>
                <Button size="lg" variant="outline" asChild className="border-2 border-primary text-primary hover:bg-primary/10 transform hover:scale-105 shadow-lg">
                  <Link to="/register">
                    <Users className="mr-2 h-6 w-6" /> Create Account
                  </Link>
                </Button>
              </motion.div>
            </div>
            <div className="absolute bottom-0 left-0 w-full h-20 bg-gradient-to-t from-background to-transparent z-0"></div>
          </motion.section>

          {/* Featured Tournaments Section */}
          <section className="space-y-8">
            <motion.h2 
              className="text-4xl font-bold text-center text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent"
              initial={{ opacity: 0, y:20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <Zap className="inline-block mr-3 h-10 w-10 text-primary" /> Featured Tournaments
            </motion.h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {featuredTournaments.map((tournament, index) => (
                <MotionCard 
                  key={tournament.id}
                  className="glassmorphic-card overflow-hidden group hover:shadow-neon transition-all duration-300"
                  initial={{ opacity: 0, y: 50 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.3 + index * 0.1 }}
                >
                  <CardHeader className="p-0 relative">
                    <div className="aspect-video overflow-hidden">
                       <img  class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" alt={tournament.name} src="https://images.unsplash.com/photo-1651608593897-0d192e019b9e" />
                    </div>
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent"></div>
                    <div className="absolute bottom-0 left-0 p-4">
                       <CardTitle className="text-2xl font-bold text-white">{tournament.name}</CardTitle>
                       <CardDescription className="text-slate-300">{tournament.game}</CardDescription>
                    </div>
                  </CardHeader>
                  <CardContent className="p-6 space-y-3">
                    <div className="flex items-center text-sm text-slate-400">
                      <CalendarDays className="mr-2 h-5 w-5 text-accent" />
                      <span>Date: {tournament.date}</span>
                    </div>
                    <div className="flex items-center text-sm text-slate-400">
                      <Trophy className="mr-2 h-5 w-5 text-yellow-400" />
                      <span>Prize Pool: {tournament.prize}</span>
                    </div>
                  </CardContent>
                  <CardFooter className="p-6 pt-0 flex justify-between items-center">
                    <Button asChild className="bg-primary/80 hover:bg-primary w-full sm:w-auto">
                      <Link to={`/tournaments/${tournament.id}`}>View Details</Link>
                    </Button>
                     <Button variant="outline" className="border-accent text-accent hover:bg-accent/10 w-full mt-2 sm:mt-0 sm:w-auto sm:ml-2" onClick={() => handleNotify(tournament.name)}>
                      Notify Me
                    </Button>
                  </CardFooter>
                </MotionCard>
              ))}
            </div>
          </section>

          {/* How It Works Section */}
          <section className="py-16 bg-slate-800/30 rounded-xl shadow-xl">
            <motion.h2 
              className="text-4xl font-bold text-center mb-12 text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent"
              initial={{ opacity: 0, y:20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              How It Works
            </motion.h2>
            <div className="grid md:grid-cols-3 gap-8 text-center px-6">
              {[
                { icon: Users, title: "Sign Up", description: "Create your account and build your gaming profile." },
                { icon: PlayCircle, title: "Find Tournaments", description: "Browse and join tournaments for your favorite games." },
                { icon: Trophy, title: "Compete & Win", description: "Showcase your skills, climb leaderboards, and win prizes." }
              ].map((step, index) => (
                <motion.div 
                  key={index} 
                  className="p-6 glassmorphic-card"
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.5, delay: 0.2 + index * 0.1 }}
                >
                  <step.icon className="h-16 w-16 text-primary mx-auto mb-6" />
                  <h3 className="text-2xl font-semibold mb-3 text-slate-100">{step.title}</h3>
                  <p className="text-slate-400">{step.description}</p>
                </motion.div>
              ))}
            </div>
          </section>
        </div>
      );
    };

    export default HomePage;
  